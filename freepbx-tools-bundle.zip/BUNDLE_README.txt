FreePBX Tools Offline Bundle
Created (UTC): 2026-01-15 21:05:17Z

This bundle contains the same files that deploy_freepbx_tools.py would upload.

Recommended manual install steps on the target server:
  1) Copy this zip to the server (example):
       scp freepbx-tools-bundle.zip 123net@<SERVER>:/home/123net/
  2) SSH to the server:
       ssh 123net@<SERVER>
  3) Unzip into the staging directory:
       rm -rf /home/123net/freepbx-tools
       mkdir -p /home/123net/freepbx-tools
       unzip -o /home/123net/freepbx-tools-bundle.zip -d /home/123net/freepbx-tools
  4) Become root and run bootstrap + install:
       su - root
       cd /home/123net/freepbx-tools
       bash bootstrap.sh
       ./install.sh

Notes:
- If you see fwconsole errors as a normal user, that is expected on some systems.
  Run FreePBX commands as root (or the appropriate service user).